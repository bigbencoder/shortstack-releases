#!/usr/bin/env bash
# STACK_SH_VERSION: 5
# ^ bumped whenever this script changes. The ShortStack app embeds a copy of this script and
#   self-installs/upgrades the one in its data dir when the on-disk version is OLDER (never
#   downgrades; backs up the old file first). Canonical source: ShortStack repo, ShortStack/stack.sh.
# stack.sh — short-term LIFO "short stack" with an append-only TSV transaction log.
# Hardened (per gpt-5.5 review): mkdir-lock concurrency, strict errors, control-char
# sanitization, numeric input validation, .stack_seq recovery. Portable macOS/BSD + Linux.
#
# State files (same dir as this script):
#   STACK.md    live stack; one item per line as TSV: <id>\t<push_epoch>\t<text>  (newest at bottom)
#   STACK.log   append-only audit log (TSV, never trimmed): iso_ts\tepoch\top\tid\tactor\tref\titem
#   .stack_seq  monotonic id counter ;  .stack.lock  mkdir mutex
#
# Nothing edits STACK.md by hand — the agent/app/CLI only call these subcommands.
# Actor from $STACK_ACTOR (agent|app|cli), default cli.
#
# Subcommands: push <t> | push-many <a> <b>.. | pop | pop-clip | peek | peek-clip |
#              show | count | clear | remove <id> | move <id> <pos> | edit <id> <t> |
#              restore <id> | history [N] | as-of <epoch>
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
F="$DIR/STACK.md"
LOG="$DIR/STACK.log"
SEQ="$DIR/.stack_seq"
LOCK="$DIR/.stack.lock"

# collapse ALL control chars (tab, newline, CR, ESC, ...) to spaces -> one safe TSV cell
sanitize(){ printf '%s' "${1-}" | tr '[:cntrl:]' ' '; }
is_int(){ case "${1-}" in ''|*[!0-9]*) return 1;; *) return 0;; esac }

ACTOR="$(sanitize "${STACK_ACTOR:-cli}")"

# ---- portable mutex: mkdir is atomic; reclaim ONLY a dead holder's lock ----
# The lock dir carries the holder PID. After ~1s of waiting we inspect it: if the
# holder process is still ALIVE (merely slow), we keep waiting and never steal —
# stealing a live holder would let two writers race and clobber STACK.md. If the
# holder is dead/unknown (crashed mid-op), we reclaim the stale lock. ~30s hard cap.
# The dead-holder check MUST fire well inside the ShortStack app's 5s subprocess
# timeout: at the old 5s threshold, reclaim always lost the race to the kill, so one
# stale lock (holder SIGKILLed, EXIT trap never ran) made EVERY app mutation time
# out forever — pushes appeared then vanished with "timed out after 5.0s".
acquire_lock(){
  local tries=0 waited=0 holder
  while ! mkdir "$LOCK" 2>/dev/null; do
    sleep 0.05; waited=$((waited + 1)); tries=$((tries + 1))
    if [ "$tries" -ge 20 ]; then
      tries=0
      holder="$(cat "$LOCK/pid" 2>/dev/null || true)"
      if [ -n "$holder" ] && kill -0 "$holder" 2>/dev/null; then
        :                                   # holder ALIVE (slow) -> wait, never steal
      else
        rm -rf "$LOCK" 2>/dev/null || true  # holder dead/unknown -> reclaim stale lock
      fi
    fi
    if [ "$waited" -ge 600 ]; then
      echo "stack: lock busy >30s, giving up" >&2; exit 1
    fi
  done
  printf '%s\n' "$$" > "$LOCK/pid" 2>/dev/null || true
  trap 'rm -rf "$LOCK" 2>/dev/null || true' EXIT INT TERM
}
acquire_lock

# init state under the lock
[ -f "$F" ]   || : > "$F"
[ -f "$LOG" ] || printf 'iso_ts\tepoch\top\tid\tactor\tref\titem\n' > "$LOG"
if [ ! -f "$SEQ" ]; then
  # recover the counter from the highest id ever seen (log col 4 + live col 1)
  maxid="$( { awk -F'\t' 'NR>1{print $4}' "$LOG" 2>/dev/null || true; cut -f1 "$F" 2>/dev/null || true; } \
            | awk 'BEGIN{m=0} /^[0-9]+$/{if($1+0>m)m=$1} END{print m}')"
  printf '%s\n' "${maxid:-0}" > "$SEQ"
fi

next_id(){ local n; n="$(cat "$SEQ")"; n=$((n + 1)); printf '%s\n' "$n" > "$SEQ"; printf '%s' "$n"; }

log_event(){ # op id ref item  (actor is the global $ACTOR)
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$(date '+%s')" \
    "$(sanitize "$1")" "$(sanitize "$2")" "$ACTOR" "$(sanitize "$3")" "$(sanitize "$4")" >> "$LOG"
}

to_clip(){ # stdin -> clipboard, best-effort, silent on failure
  if   command -v pbcopy  >/dev/null 2>&1; then pbcopy 2>/dev/null
  elif command -v wl-copy >/dev/null 2>&1; then wl-copy 2>/dev/null
  elif command -v xclip   >/dev/null 2>&1; then xclip -selection clipboard 2>/dev/null
  else cat >/dev/null; return 1; fi
}

build_ref(){ # dest win ttl -> "k=v;k=v" or "-"  (delimiters stripped from values)
  local d w t parts san
  d="$1"; w="$2"; t="$3"; parts=""
  san(){ printf '%s' "${1-}" | tr ';=\t\n' '    '; }
  [ -n "$d" ] && parts="dest=$(san "$d")"
  [ -n "$w" ] && parts="${parts:+$parts;}win=$(san "$w")"
  if [ -n "$t" ]; then is_int "$t" && parts="${parts:+$parts;}ttl=$t"; fi
  printf '%s' "${parts:--}"
}

push_item(){ # text [op=push] [ref=-] -> echoes new id
  local text op ref id
  text="$(sanitize "$1")"; op="${2:-push}"; ref="${3:--}"
  id="$(next_id)"
  printf '%s\t%s\t%s\n' "$id" "$(date '+%s')" "$text" >> "$F"
  log_event "$op" "$id" "$ref" "$text"
  printf '%s' "$id"
}

sub="${1:-show}"; if [ "$#" -gt 0 ]; then shift; fi
case "$sub" in
  push)
    dest=""; win=""; ttl=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        --dest) dest="${2-}"; shift 2 ;;
        --win)  win="${2-}";  shift 2 ;;
        --ttl)  ttl="${2-}";  shift 2 ;;   # seconds; urgency starts after this elapses
        --) shift; break ;;
        *) break ;;
      esac
    done
    text="$*"
    [ -n "${text//[[:space:]]/}" ] || { echo "push: nothing to push" >&2; exit 1; }
    id="$(push_item "$text" "push" "$(build_ref "$dest" "$win" "$ttl")")"
    echo "pushed #$id: $(sanitize "$text")"
    ;;

  push-many)
    n=0
    for item in "$@"; do
      [ -n "${item//[[:space:]]/}" ] || continue
      push_item "$item" "push-many" >/dev/null
      n=$((n + 1))
    done
    echo "pushed $n item(s)"
    ;;

  pop|pop-clip)
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    last="$(tail -n 1 "$F")"
    id="$(printf '%s' "$last" | cut -f1)"
    text="$(printf '%s' "$last" | cut -f3-)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! sed '$d' "$F" > "$tmp"; then rm -f "$tmp"; echo "pop: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    if [ "$sub" = pop-clip ]; then
      if printf '%s' "$text" | to_clip; then note=" (copied to clipboard)"; else note=" (clipboard unavailable)"; fi
      log_event "pop-clip" "$id" "-" "$text"
      echo "popped #$id$note: $text"
    else
      log_event "pop" "$id" "-" "$text"
      echo "popped #$id: $text"
    fi
    ;;

  peek|peek-clip)
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    last="$(tail -n 1 "$F")"
    id="$(printf '%s' "$last" | cut -f1)"
    text="$(printf '%s' "$last" | cut -f3-)"
    if [ "$sub" = peek-clip ]; then
      if printf '%s' "$text" | to_clip; then note=" (copied to clipboard)"; else note=" (clipboard unavailable)"; fi
      log_event "peek-clip" "$id" "-" "$text"
      echo "top #$id$note: $text"
    else
      echo "top #$id: $text"
    fi
    ;;

  show)
    if [ ! -s "$F" ]; then echo "stack is empty (0 items)"; exit 0; fi
    awk -F'\t' -v now="$(date '+%s')" '
      {a[NR]=$0}
      END{
        k=0
        for(i=NR;i>=1;i--){
          split(a[i],c,"\t"); id=c[1]; ep=c[2]; txt=c[3]; d=now-ep
          if(d<60)         age=d "s"
          else if(d<3600)  age=int(d/60) "m"
          else if(d<86400) age=int(d/3600) "h"
          else             age=int(d/86400) "d"
          printf "%d. %s  (#%s, %s ago)\n", ++k, txt, id, age
        }
      }' "$F"
    ;;

  count)
    awk 'END{print NR+0}' "$F"
    ;;

  clear)
    log_event "clear" "-" "-" ""
    : > "$F"
    echo "stack cleared"
    ;;

  remove)
    target="${1:-}"
    is_int "$target" || { echo "remove: id must be a positive integer" >&2; exit 1; }
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "remove: id #$target not in stack" >&2; exit 1; }
    text="$(printf '%s' "$line" | cut -f3-)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! awk -F'\t' -v id="$target" '$1!=id' "$F" > "$tmp"; then rm -f "$tmp"; echo "remove: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    log_event "remove" "$target" "-" "$text"
    echo "removed #$target: $text"
    ;;

  move)
    # move <id> <pos> — reorder a live item to position <pos>, 1-based from the TOP
    # (matching `show` numbering: 1 = top). Appends op=move with ref "to=<pos>".
    target="${1:-}"; pos="${2:-}"
    is_int "$target" || { echo "move: id must be a positive integer" >&2; exit 1; }
    is_int "$pos" || { echo "move: position must be a positive integer (1 = top)" >&2; exit 1; }
    if [ ! -s "$F" ]; then echo "stack is empty"; exit 0; fi
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "move: id #$target not in stack" >&2; exit 1; }
    text="$(printf '%s' "$line" | cut -f3-)"
    n="$(awk 'END{print NR+0}' "$F")"
    [ "$pos" -ge 1 ] || pos=1
    [ "$pos" -le "$n" ] || pos="$n"
    # STACK.md is newest-at-bottom, so position <pos> from the top = line (n - pos + 1).
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    if ! awk -F'\t' -v id="$target" -v pos="$pos" -v n="$n" '
      BEGIN{ dest=n-pos+1 }
      $1==id{ saved=$0; next }
      { rest[++k]=$0 }
      END{
        printed=0
        for(i=1;i<=k+1;i++){
          if(i==dest){ print saved; printed=1 }
          if(i<=k) print rest[i]
        }
        if(!printed) print saved
      }' "$F" > "$tmp"; then rm -f "$tmp"; echo "move: write failed" >&2; exit 1; fi
    mv "$tmp" "$F"
    log_event "move" "$target" "to=$pos" "$text"
    echo "moved #$target to position $pos: $text"
    ;;

  edit)
    # edit <id> <text…> — replace a live item's text in place (id + push epoch preserved,
    # so age/urgency are unaffected). Appends op=edit with the new text.
    target="${1:-}"; shift || true
    is_int "$target" || { echo "edit: id must be a positive integer" >&2; exit 1; }
    text="$(sanitize "$*")"
    [ -n "${text//[[:space:]]/}" ] || { echo "edit: nothing to set" >&2; exit 1; }
    # A dropped edit is USER DATA LOSS (their typed text) — unlike pop/move, an empty stack
    # here must fail loudly (exit 1 + stderr) so the app surfaces it instead of silently
    # reverting the optimistic text.
    [ -s "$F" ] || { echo "edit: stack is empty; #$target is gone" >&2; exit 1; }
    line="$(awk -F'\t' -v id="$target" '$1==id{print; exit}' "$F")"
    [ -n "$line" ] || { echo "edit: id #$target not in stack" >&2; exit 1; }
    ep="$(printf '%s' "$line" | cut -f2)"
    tmp="$(mktemp "$DIR/.STACK.md.XXXXXX")"
    # text via ENVIRON (awk -v mangles backslashes)
    if ! TXT="$text" awk -F'\t' -v id="$target" -v ep="$ep" \
        'BEGIN{OFS="\t"; t=ENVIRON["TXT"]} $1==id{print id,ep,t; next} {print}' "$F" > "$tmp"; then
      rm -f "$tmp"; echo "edit: write failed" >&2; exit 1
    fi
    mv "$tmp" "$F"
    log_event "edit" "$target" "-" "$text"
    echo "edited #$target: $text"
    ;;

  restore)
    target="${1:-}"
    is_int "$target" || { echo "restore: id must be a positive integer" >&2; exit 1; }
    item="$(awk -F'\t' -v id="$target" \
      '($3=="push"||$3=="push-many"||$3=="restore") && $4==id {v=$7} END{print v}' "$LOG")"
    [ -n "$item" ] || { echo "restore: id #$target not found in log" >&2; exit 1; }
    origref="$(awk -F'\t' -v id="$target" \
      '($3=="push"||$3=="push-many"||$3=="restore") && $4==id {v=$6} END{print v}' "$LOG")"
    [ -n "$origref" ] || origref="-"
    if [ "$origref" = "-" ]; then ref="src=$target"; else ref="$origref;src=$target"; fi
    newid="$(push_item "$item" "restore" "$ref")"
    echo "restored #$target as #$newid: $item"
    ;;

  history)
    n="${1:-20}"
    is_int "$n" || { echo "history: N must be a positive integer" >&2; exit 1; }
    echo "(last $n transactions)"
    tail -n "$n" "$LOG" | awk -F'\t' '$1!="iso_ts"{printf "%s  %-9s #%-4s %-6s %s\n",$1,$3,$4,$5,$7}'
    ;;

  as-of)
    when="${1:-}"
    is_int "$when" || { echo "as-of: needs an epoch timestamp (integer)" >&2; exit 1; }
    awk -F'\t' -v cut="$when" '
      $1=="iso_ts"{next}
      $2+0>cut{next}
      { op=$3; id=$4; txt=$7 }
      op=="push"||op=="push-many"||op=="restore"{ top++; sid[top]=id; stx[top]=txt; next }
      op=="pop"||op=="pop-clip"{ if(top>0) top--; next }
      op=="clear"{ top=0; next }
      END{
        if(top<1){ print "stack was empty at that time"; exit }
        k=0
        for(i=top;i>=1;i--) printf "%d. %s  (#%s)\n", ++k, stx[i], sid[i]
      }' "$LOG"
    ;;

  dump-tsv)
    # Machine-readable current stack, top last: id<TAB>epoch<TAB>actor<TAB>text  (PRD §12 R2)
    [ -f "$LOG" ] || exit 0
    awk -F'\t' '
      $1=="iso_ts"{next}
      { op=$3; id=$4; ep=$2; ac=$5; tx=$7 }
      op=="push"||op=="push-many"||op=="restore"{ top++; sid[top]=id; sep[top]=ep; sac[top]=ac; stx[top]=tx; next }
      op=="pop"||op=="pop-clip"{ if(top>0) top--; next }
      op=="clear"{ top=0; next }
      END{ for(i=1;i<=top;i++) printf "%s\t%s\t%s\t%s\n", sid[i], sep[i], sac[i], stx[i] }
    ' "$LOG"
    ;;

  as-of-index)
    # Replay the first N log events (deterministic, disambiguates same-epoch bursts). PRD §12 R3.
    n="${1:-}"
    is_int "$n" || { echo "as-of-index: N must be a non-negative integer" >&2; exit 1; }
    [ -f "$LOG" ] || exit 0
    awk -F'\t' -v lim="$n" '
      $1=="iso_ts"{next}
      { c++; if(c>lim) next; op=$3; id=$4; ep=$2; ac=$5; tx=$7 }
      c<=lim && (op=="push"||op=="push-many"||op=="restore"){ top++; sid[top]=id; sep[top]=ep; sac[top]=ac; stx[top]=tx; next }
      c<=lim && (op=="pop"||op=="pop-clip"){ if(top>0) top--; next }
      c<=lim && op=="clear"{ top=0; next }
      END{ for(i=1;i<=top;i++) printf "%s\t%s\t%s\t%s\n", sid[i], sep[i], sac[i], stx[i] }
    ' "$LOG"
    ;;

  *)
    echo "usage: stack.sh push [--dest APP] [--win TITLE] [--ttl SECS] <t> | push-many <a> <b>.. | pop | pop-clip | peek | peek-clip | show | count | clear | remove <id> | move <id> <pos> | edit <id> <t> | restore <id> | history [N] | as-of <epoch> | dump-tsv | as-of-index <N>" >&2
    exit 1
    ;;
esac
